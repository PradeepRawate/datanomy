export const MAX_TEMP =  30;
export const SECRET = 'safemeds';
