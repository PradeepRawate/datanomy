import { Component, OnInit } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Shipment } from './shipment.model';
import { MAX_TEMP, SECRET } from '../app.constant';

declare var $: any;

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  key: string;
  secretError: boolean;
  timer: any;
  timerToggle: boolean;
  maxTemperature = MAX_TEMP;
  shipments = [];
  selectedShipment: Shipment;
  // shipments = [{ 'man': '11', 'd': '22', 'hsd': '11', 'ld': '33', 'sel': '11', 'status': 'PASS' },
  // { 'man': '11', 'd': '22', 'hsd': '11', 'ld': '33', 'sel': '11', 'status': 'PASS' },
  // { 'man': '11', 'd': '22', 'hsd': '11', 'ld': '33', 'sel': '11', 'status': 'PASS' },
  // { 'man': '11', 'd': '22', 'hsd': '11', 'ld': '33', 'sel': '11', 'status': 'FAIL' },
  // { 'man': '11', 'd': '22', 'hsd': '11', 'ld': '33', 'sel': '11', 'status': 'PASS' },
  // { 'man': '11', 'd': '22', 'hsd': '11', 'ld': '33', 'sel': '11', 'status': 'PASS' },
  // { 'man': '11', 'd': '22', 'hsd': '11', 'ld': '33', 'sel': '11', 'status': 'FAIL' },
  // { 'man': '11', 'd': '22', 'hsd': '11', 'ld': '33', 'sel': '11', 'status': 'PASS' },
  // { 'man': '11', 'd': '22', 'hsd': '11', 'ld': '33', 'sel': '11', 'status': 'PASS' },
  // { 'man': '11', 'd': '22', 'hsd': '11', 'ld': '33', 'sel': '11', 'status': 'FAIL' },
  // { 'man': '11', 'd': '22', 'hsd': '11', 'ld': '33', 'sel': '11', 'status': 'PASS' },
  // { 'man': '11', 'd': '22', 'hsd': '11', 'ld': '33', 'sel': '11', 'status': 'PASS' },
  // { 'man': '11', 'd': '22', 'hsd': '11', 'ld': '33', 'sel': '11', 'status': 'FAIL' },
  // { 'man': '11', 'd': '22', 'hsd': '11', 'ld': '33', 'sel': '11', 'status': 'PASS' },
  // { 'man': '11', 'd': '22', 'hsd': '11', 'ld': '33', 'sel': '11', 'status': 'PASS' }];

  constructor(private _http: Http) {
    // this.getTimeSeries();
    // this.timer = setInterval(() => this.getTimeSeries(), 2000);
  }

  ngOnInit() {
    this.getTimeSeries();
    // this._http.get('http://localhost:3000/account')
    //   .subscribe((res) => {
    //     console.log(res.text());
    //   });
  }

  getTimeSeriesPLAY() {
    this.getTimeSeries();
    this.timer = setInterval(() => this.getTimeSeries(), 2000);
  }

  getTimeSeries(): void {
    // this.timerToggle = true;
    const headers1 = new Headers({ 'Access-Control-Allow-Origin': 'http://localhost:4200' });
    headers1.append('Content-Type', 'application/json');

    // this._http.get('http://132.186.65.165:8090/api/iottimeseries/v3/timeseries', { headers: headers1 })
    //   .subscribe((res) => {
    //     console.log(res.text());
    //     this.timerToggle = false;
    //     this.shipments.push(this.populateShipment(res.text()));
    //   });
    // this._http.get('http://132.186.66.28:3000/getShipmentData')
    //   .subscribe((res) => {
    //     console.log(res.text());
    //     this.timerToggle = false;
    //     this.shipments.push(this.populateShipment(res.text()));
    //   });
    // return this.http.get('../../assets/datasets.json').subscribe(response => {
    //   this.datasets = response;
    // });
    this._http.get('../../assets/shipments.json')
      .subscribe((res) => {
        console.log(res.text());
        this.timerToggle = false;
        this.shipments.push(this.populateShipment(res.text()));
      });
  }

  stopGettingData() {
    this.timerToggle = false;
    clearInterval(this.timer);
  }

  populateShipment(shipment): Shipment {
    let shipmentData = new Shipment();
    shipmentData = JSON.parse(shipment);
    shipmentData.status = this.getStatus(shipmentData);
    shipmentData['shipmentId'] = Math.floor(Math.random() * 1000000000);
    console.log('res: ', shipmentData);
    return shipmentData;
  }

  getStatus(shipment) {
    return shipment.manufacturer > this.maxTemperature ? 'FAIL' : shipment.dist > this.maxTemperature ? 'FAIL' :
      shipment.wholesaler > this.maxTemperature ? 'FAIL' : shipment.retailer > this.maxTemperature ? 'FAIL' :
        shipment.pharmacy > this.maxTemperature ? 'FAIL' : 'PASS';
  }

  openShipmentStatus(secret) {
    if (this.validateKey(secret)) {
      this.secretError = false;
      setTimeout(() => {
        $('.status').modal('show');
      }, 500);
    } else {
      this.secretError = true;
    }
  }

  validateKey(secret) {
    return secret === SECRET;
  }

  openSecretPopup(shipment) {
    this.selectedShipment = shipment;
    this.key = '';
    $('.ui.modal.password')
      .modal({
        // selector: {
        //   close: '.actions .button',
        //   deny: '.actions .negative, .actions .deny, .actions .cancel, .close'
        // },
        closable: false,
        blurring: true,
        onDeny: function () {
          // window.alert('Wait not yet!');
          return false;
        },
        onApprove: function () {
          // return this.validateKey(this.key);
          return false;
        }
      })
      .modal('show');
  }
}
