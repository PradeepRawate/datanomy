export class Shipment {
    manufacturer: string;
    dist: string;
    wholesaler: string;
    retailer: string;
    pharmacy: string;
    status: string;
}
